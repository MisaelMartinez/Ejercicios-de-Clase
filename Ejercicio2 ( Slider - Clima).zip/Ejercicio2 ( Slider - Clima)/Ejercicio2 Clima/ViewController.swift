//
//  ViewController.swift
//  Ejercicio2 Clima
//
//  Created by Macbook on 06/03/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var Imagen: UIImageView!
    
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var labelClima: UILabel!
    
    
    @IBAction func slider(_ sender: UISlider) {
        let valor = Int(slider.value * 100)
        let cadena = "\(valor)"
        label.text = cadena
        
        switch valor {
        case 0...20:
            labelClima.text = "Asoleado"
            Imagen.image = UIImage(named: "sun-34485_960_720.jpg")
            
        
            
        case 21...40:
            labelClima.text = "Nublado"
            Imagen.image = UIImage(named: "images.jpg")
            
        case 41...60:
            labelClima.text = "Lluvioso"
         Imagen.image = UIImage(named: "Unknown-1.jpg")
            
        case 61...80:
            labelClima.text = "Granizo"
            Imagen.image = UIImage(named: "Unknown.jpg")
            
        default:
            labelClima.text = "Nieve"
            
            Imagen.image = UIImage(named: "Unknown-2.jpg")
            
        }

    
    
    
    
    
    
    
    
    
    
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }




}


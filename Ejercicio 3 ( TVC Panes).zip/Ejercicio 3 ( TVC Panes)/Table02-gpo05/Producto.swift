//
//  Producto.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var precio: Double
    var imagen: String
    var precioAPagar : Double
}

var Ind = 0

let brownies = Producto(nombre: "Brownie", desc: "Pan de chocolate", precio: 3.99, imagen: "brownies", precioAPagar: 0)

let bagels = Producto(nombre: "Bagels", desc: "Pan rico", precio: 3.99, imagen: "bagels", precioAPagar: 0)

let butter = Producto(nombre: "Butter", desc: "Es un manjar", precio: 4, imagen: "butter", precioAPagar: 0)

let chesse = Producto(nombre: "Chesse", desc: "Rico queso", precio: 8.99, imagen: "cheese", precioAPagar: 0)

let coffee = Producto(nombre: "Coffe", desc: "Cafe americano ", precio: 5.99, imagen: "coffee", precioAPagar: 0)

let donuts = Producto(nombre: "Donuts", desc: "Donas cubiertas de chocolate", precio: 2.99, imagen: "donuts", precioAPagar: 0)

let cookies = Producto(nombre: "Cookies", desc: "Galletas con piscas de chocolate", precio: 4.99, imagen: "cookies", precioAPagar: 0)

let granola = Producto(nombre: "Granola", desc: "Alimento formado por nueces, copos de avena mezclados con miel y otros ingredientes naturales", precio: 3.99, imagen: "granola", precioAPagar: 0)

let juice = Producto(nombre: "Juice", desc: "Jugo de naranja ", precio: 1.99, imagen: "juice", precioAPagar: 0)

let lemonade = Producto(nombre: "Lemonade", desc: "Jugo de limon con hielo", precio: 2.99, imagen: "lemonade", precioAPagar: 0)

let lettuce = Producto(nombre: "lettuce", desc: "Lechuga", precio: 0.99, imagen: "lettuce", precioAPagar: 0)

let milk = Producto(nombre: "Milk", desc: "Leche", precio: 1.99, imagen: "milk", precioAPagar: 0)

let onions = Producto(nombre: "Onions", desc: "Cebolla", precio: 1.99, imagen: "onions", precioAPagar: 0)

let potato = Producto(nombre: "Potato", desc: "Papa blancas ", precio: 3.99, imagen: "potato", precioAPagar: 0)

let tea = Producto(nombre: "Tea", desc: "Te de limon", precio: 1.99, imagen: "tea", precioAPagar: 0)

let tomato = Producto(nombre: "Tomato", desc: "Jitomate rojo", precio: 5, imagen: "tomato", precioAPagar: 0)

let yogurt = Producto(nombre: "Yogurt", desc: "Yogurt de fresa", precio: 0.49, imagen: "yogurt" , precioAPagar: 0)





var articulos = [brownies, bagels, butter, chesse  , coffee, donuts, cookies, granola, juice, lemonade, lettuce, milk, onions, potato, tea, tomato, yogurt]

